/** Automatically generated file. DO NOT MODIFY */
package com.neurondigital.twofourzeroeight;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}